
import java.util.*;

/**
 * 
 */
public class Counter {

    /**
     * Default constructor
     */
    public Counter() {
    }

    /**
     * 
     */
    private DateTime deadline;



    /**
     * @return
     */
    public bool alarm() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void start() {
        // TODO implement here
    }

    /**
     * 
     */
    public void stop() {
        // TODO implement here
    }

    /**
     * 
     */
    public void pause() {
        // TODO implement here
    }

    /**
     * @param int
     */
    public void increase(numberOfHours int) {
        // TODO implement here
    }

}