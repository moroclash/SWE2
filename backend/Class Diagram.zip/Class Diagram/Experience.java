
import java.util.*;

/**
 * 
 */
public class Experience {

    /**
     * Default constructor
     */
    public Experience() {
    }

    /**
     * 
     */
    private File picture;

    /**
     * 
     */
    private String link;

    /**
     * 
     */
    private String summary;

    /**
     * 
     */
    private ArrayList<String> technologies;


}