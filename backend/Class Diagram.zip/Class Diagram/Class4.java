
import java.util.*;

/**
 * 
 */
public class Class4 {

    /**
     * Default constructor
     */
    public Class4() {
    }

}