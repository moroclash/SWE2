
import java.util.*;

/**
 * 
 */
public class Class1 {

    /**
     * Default constructor
     */
    public Class1() {
    }

}