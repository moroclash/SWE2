
import java.util.*;

/**
 * 
 */
public interface Display {

    /**
     * @param path 
     * @return
     */
    public Pdf Print(String path);

}