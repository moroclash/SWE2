
import java.util.*;

/**
 * 
 */
public class AccountFactory {

    /**
     * Default constructor
     */
    public AccountFactory() {
    }

    /**
     * @param name 
     * @return
     */
    public Account GetAccount(String name) {
        // TODO implement here
        return null;
    }

}