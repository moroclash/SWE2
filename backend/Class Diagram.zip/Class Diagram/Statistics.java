
import java.util.*;

/**
 * 
 */
public class Statistics {

    /**
     * Default constructor
     */
    public Statistics() {
    }

    /**
     * 
     */
    private double totalMoney;

    /**
     * 
     */
    private double ourMoney;

    /**
     * 
     */
    private int numberOfEmployers;

    /**
     * 
     */
    private int numberOfFreelancers;

    /**
     * 
     */
    private int numberOfAllTasks;

    /**
     * 
     */
    private int numberOfAcceptedTasks;

    /**
     * 
     */
    private int numberOfRejectedTasks;

    /**
     * 
     */
    private int numberOfComplaints;

    /**
     * 
     */
    private int numberOfAdmins;

    /**
     * 
     */
    private int numberOfBlockedPeople;

    /**
     * 
     */
    private Statistics static statistics;




    /**
     * @return
     */
    public void Statistics() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    private void Statistics() {
        // TODO implement here
    }

    /**
     * @return
     */
    public Statistics GetInstance() {
        // TODO implement here
        return null;
    }

}