
import java.util.*;

/**
 * 
 */
public class EmployerProfile extends Profile {

    /**
     * Default constructor
     */
    public EmployerProfile() {
    }


}