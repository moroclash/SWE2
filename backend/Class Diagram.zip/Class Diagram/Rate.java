
import java.util.*;

/**
 * 
 */
public class Rate {

    /**
     * Default constructor
     */
    public Rate() {
    }

    /**
     * 
     */
    private int theRate;


    /**
     * @param ratio
     */
    public void increase(int ratio) {
        // TODO implement here
    }

    /**
     * @param ratio
     */
    public void decrease(int ratio) {
        // TODO implement here
    }

    /**
     * 
     */
    public void recalculateRate() {
        // TODO implement here
    }

}