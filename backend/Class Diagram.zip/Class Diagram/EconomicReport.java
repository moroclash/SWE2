
import java.util.*;

/**
 * 
 */
public class EconomicReport implements Report {

    /**
     * Default constructor
     */
    public EconomicReport() {
    }

    /**
     * @return
     */
    public Statistics GetStatistics() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String GetDescription() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public DateTime GetDate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String Next() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public bool HasNext() {
        // TODO implement here
        return null;
    }

}