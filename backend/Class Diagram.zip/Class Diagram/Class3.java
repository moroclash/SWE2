
import java.util.*;

/**
 * 
 */
public class Class3 {

    /**
     * Default constructor
     */
    public Class3() {
    }

}