
import java.util.*;

/**
 * 
 */
public class Task {

    /**
     * Default constructor
     */
    public Task() {
    }

    /**
     * 
     */
    private File task;

    /**
     * 
     */
    private unsigned int timeTaken;

    /**
     * 
     */
    private ArrayList<Offer> offers;

    /**
     * 
     */
    private Employer employer;

    /**
     * 
     */
    private int taskID;

    /**
     * 
     */
    private String category;

    /**
     * 
     */
    private int state;

    /**
     * 
     */
    private DateTime date;

    /**
     * 
     */
    public ArrayList<String> technologies;











    /**
     * @return
     */
    public Bool uploadTask() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Bool cancelTask() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public bool editTask() {
        // TODO implement here
        return null;
    }

}