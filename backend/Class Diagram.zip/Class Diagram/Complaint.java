
import java.util.*;

/**
 * 
 */
public class Complaint {

    /**
     * Default constructor
     */
    public Complaint() {
    }

    /**
     * 
     */
    private Straing message;

    /**
     * 
     */
    private int seenState;

    /**
     * 
     */
    private Account owner;

    /**
     * 
     */
    private ArrayList<Complaint> replies;

    /**
     * 
     */
    private DateTime date;

    /**
     * 
     */
    public ConsumerAccount make;










    /**
     * 
     */
    public Complaint reply;




    /**
     * 
     */
    public void seen() {
        // TODO implement here
    }

    /**
     * 
     */
    public void unseen() {
        // TODO implement here
    }

    /**
     * 
     */
    public void isSeen() {
        // TODO implement here
    }

}