
import java.util.*;

/**
 * 
 */
public class Database {

    /**
     * Default constructor
     */
    public Database() {
    }

    /**
     * 
     */
    private String Username;

    /**
     * 
     */
    private String Password;

    /**
     * 
     */
    public void Url; String;

    /**
     * 
     */
    private Database static database;


    /**
     * @return
     */
    public bool Connect() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public bool Disconnect() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void Insert() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Update() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Delete() {
        // TODO implement here
    }

    /**
     * 
     */
    private void Database() {
        // TODO implement here
    }

    /**
     * @return
     */
    public Database GetInstance() {
        // TODO implement here
        return null;
    }

}