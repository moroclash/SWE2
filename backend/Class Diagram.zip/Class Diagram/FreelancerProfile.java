
import java.util.*;

/**
 * 
 */
public class FreelancerProfile extends Profile {

    /**
     * Default constructor
     */
    public FreelancerProfile() {
    }

    /**
     * 
     */
    private int averageHourCost;

    /**
     * 
     */
    private ArrayList<Feedback> reviews;



}