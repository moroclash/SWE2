
import java.util.*;

/**
 * 
 */
public class OverTimeRequest {

    /**
     * Default constructor
     */
    public OverTimeRequest() {
    }

    /**
     * 
     */
    private int hoursNeeded;

    /**
     * 
     */
    private Offer offer;

    /**
     * 
     */
    private String description;

    /**
     * 
     */
    private int state;

    /**
     * 
     */
    private DateTime date;



}