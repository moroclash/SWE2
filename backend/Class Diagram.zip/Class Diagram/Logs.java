
import java.util.*;

/**
 * 
 */
public interface Logs {

    /**
     * @return
     */
    public ArrayList<Log> getLog();

}