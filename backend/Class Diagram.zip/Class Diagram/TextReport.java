
import java.util.*;

/**
 * 
 */
public class TextReport extends ReportManager implements Display {

    /**
     * Default constructor
     */
    public TextReport() {
    }

    /**
     * @param path 
     * @return
     */
    public Pdf Print(String path) {
        // TODO implement here
        return null;
    }

}