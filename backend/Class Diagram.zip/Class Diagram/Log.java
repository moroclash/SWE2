
import java.util.*;

/**
 * 
 */
public class Log {

    /**
     * Default constructor
     */
    public Log() {
    }

    /**
     * 
     */
    public DateTime date;

    /**
     * 
     */
    public int accountID;

    /**
     * 
     */
    public String action;

}