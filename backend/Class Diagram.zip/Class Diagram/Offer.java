
import java.util.*;

/**
 * 
 */
public class Offer {

    /**
     * Default constructor
     */
    public Offer() {
    }

    /**
     * 
     */
    private int hourCost;

    /**
     * 
     */
    private int numberOfHours;

    /**
     * 
     */
    private String description;

    /**
     * 
     */
    private Freelancer owner;

    /**
     * 
     */
    private Counter counter;

    /**
     * 
     */
    private Task task;

    /**
     * 
     */
    private int offerID;

    /**
     * 
     */
    private int state;

    /**
     * 
     */
    private DateTime date;

    /**
     * 
     */
    private int timeNeeded;








    /**
     * 
     */
    public void cancelOffer() {
        // TODO implement here
    }

    /**
     * 
     */
    public void acceptOffer() {
        // TODO implement here
    }

    /**
     * @return
     */
    public bool editOffer() {
        // TODO implement here
        return null;
    }

}