
import java.util.*;

/**
 * 
 */
public class Constraints {

    /**
     * Default constructor
     */
    public Constraints() {
    }

    /**
     * 
     */
    private int fr_timeoutPenalty;

    /**
     * 
     */
    private int fr_cancelingTaskPenalty;

    /**
     * 
     */
    private int fr_overtimePenalty;

    /**
     * 
     */
    private int em_rejectFinishedTaskPenalty;

    /**
     * 
     */
    private int em_cancelRunningTaskPenalty;

    /**
     * 
     */
    private int em_cancelRunningTaskBudgetPenalty;

    /**
     * 
     */
    private int em_rejectFinishedTaskBudgetPenalty;

    /**
     * 
     */
    private int ourProfit;

    /**
     * 
     */
    private Constraints static constrain;





    /**
     * 
     */
    private void Constraints() {
        // TODO implement here
    }

    /**
     * @return
     */
    public Constraints GetInstance() {
        // TODO implement here
        return null;
    }

}