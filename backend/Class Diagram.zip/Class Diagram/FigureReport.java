
import java.util.*;

/**
 * 
 */
public class FigureReport extends ReportManager implements Display {

    /**
     * Default constructor
     */
    public FigureReport() {
    }

    /**
     * @param path 
     * @return
     */
    public Pdf Print(String path) {
        // TODO implement here
        return null;
    }

}