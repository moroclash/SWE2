
import java.util.*;

/**
 * 
 */
public class System {

    /**
     * Default constructor
     */
    public System() {
    }

    /**
     * 
     */
    private Constraints constraints;

    /**
     * 
     */
    private ArrayList<Complaint> unseenComplaints;

    /**
     * 
     */
    private Statistics statistics;

    /**
     * 
     */
    private System static sys;












    /**
     * @param id 
     * @return
     */
    public Task getTask(int id) {
        // TODO implement here
        return null;
    }

    /**
     * @param id 
     * @return
     */
    public Offer getOffer(int id) {
        // TODO implement here
        return null;
    }

    /**
     * @param searchKey 
     * @param mode 
     * @return
     */
    public ConsumerAccount getAccount(String searchKey, int mode) {
        // TODO implement here
        return null;
    }

    /**
     * @param notification 
     * @return
     */
    public bool notifyAll(Notification notification) {
        // TODO implement here
        return null;
    }

    /**
     * @param freelancer 
     * @return
     */
    public ArrayList<Task> taskFeed(Freelancer freelancer) {
        // TODO implement here
        return null;
    }

    /**
     * @param technologies 
     * @return
     */
    public ArrayList<Task> taskFilter(ArrayList<String> technologies) {
        // TODO implement here
        return null;
    }

    /**
     * @param category 
     * @return
     */
    public ArrayList<Task> taskFilter(String category) {
        // TODO implement here
        return null;
    }

    /**
     * @param category 
     * @return
     */
    public bool addCategory(String category) {
        // TODO implement here
        return null;
    }

    /**
     * @param category 
     * @return
     */
    public bool deleteCategory(Sting category) {
        // TODO implement here
        return null;
    }

    /**
     * @param technology 
     * @return
     */
    public bool addTechnology(Sting technology) {
        // TODO implement here
        return null;
    }

    /**
     * @param technology 
     * @return
     */
    public bool deleteTechnology(Sting technology) {
        // TODO implement here
        return null;
    }

    /**
     * @param oldTech 
     * @param newTech 
     * @return
     */
    public bool updateTechnology(String oldTech, String newTech) {
        // TODO implement here
        return null;
    }

    /**
     * @param oldCate 
     * @param newCatech 
     * @return
     */
    public bool updateCategory(String oldCate, String newCatech) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public ArrayList<Complaints> getSeenComplaints() {
        // TODO implement here
        return null;
    }

    /**
     * @param userName 
     * @param passwd 
     * @return
     */
    public Object getAccess(String userName, String passwd) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public System GetInstance() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    private void System() {
        // TODO implement here
    }

}