
import java.util.*;

/**
 * 
 */
public class Account implements systemAccess {

    /**
     * Default constructor
     */
    public Account() {
    }

    /**
     * 
     */
    private String firstName;

    /**
     * 
     */
    private String lastName;

    /**
     * 
     */
    private String phone;

    /**
     * 
     */
    private String iD;

    /**
     * 
     */
    private String password;

    /**
     * 
     */
    private String userName;

    /**
     * 
     */
    private bool blockState;

    /**
     * 
     */
    private DateTime date;


    /**
     * @return
     */
    public bool block() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public bool unblock() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public bool remove() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public bool logout() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void updateProfile() {
        // TODO implement here
    }

}