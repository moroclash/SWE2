
import java.util.*;

/**
 * 
 */
public class Notification {

    /**
     * Default constructor
     */
    public Notification() {
    }

    /**
     * 
     */
    public Account from;

    /**
     * 
     */
    public Account to;

    /**
     * 
     */
    public DateTime date;

    /**
     * 
     */
    public String message;

    /**
     * 
     */
    public Bool state;




}