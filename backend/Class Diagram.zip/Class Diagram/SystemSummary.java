
import java.util.*;

/**
 * 
 */
public class SystemSummary implements Report {

    /**
     * Default constructor
     */
    public SystemSummary() {
    }

    /**
     * @return
     */
    public Constraints GetConstraint() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Statistics GetStatistics() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String GetDescription() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public DateTime GetDate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String Next() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public bool HasNext() {
        // TODO implement here
        return null;
    }

}