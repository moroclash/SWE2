
import java.util.*;

/**
 * 
 */
public class ReportManager {

    /**
     * Default constructor
     */
    public ReportManager() {
    }

    /**
     * 
     */
    private Report report;


    /**
     * @return
     */
    public String GetReportDescription() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public Date GetReportDate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String NextReport() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public bool HasNextReport() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Time GetReportTime() {
        // TODO implement here
        return null;
    }

}