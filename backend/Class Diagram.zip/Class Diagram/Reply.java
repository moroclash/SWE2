
import java.util.*;

/**
 * 
 */
public class Reply {

    /**
     * Default constructor
     */
    public Reply() {
    }

    /**
     * 
     */
    public String message;


}