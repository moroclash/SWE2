
import java.util.*;

/**
 * 
 */
public class Profile {

    /**
     * Default constructor
     */
    public Profile() {
    }

    /**
     * 
     */
    private File picture;

    /**
     * 
     */
    private String description;

    /**
     * 
     */
    private Rate rate;

    /**
     * 
     */
    private double totalMoney;

    /**
     * 
     */
    private int numberOfTasks;


    /**
     * @param picture
     */
    public void uploadPicture(File picture) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Bool editProfile() {
        // TODO implement here
        return null;
    }

}