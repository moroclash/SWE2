
import java.util.*;

/**
 * 
 */
public interface systemAccess {

    /**
     * @return
     */
    public bool logout();

    /**
     * 
     */
    public void updateProfile();

}