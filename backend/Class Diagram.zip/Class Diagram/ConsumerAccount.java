
import java.util.*;

/**
 * 
 */
public class ConsumerAccount extends Account {

    /**
     * Default constructor
     */
    public ConsumerAccount() {
    }

    /**
     * 
     */
    private String birthDate;

    /**
     * 
     */
    private String country;

    /**
     * 
     */
    private String visaNumber;

    /**
     * 
     */
    private ArrayList<Notification> notifications;




    /**
     * @param complaint
     */
    public void makeComplaint(Complaint complaint) {
        // TODO implement here
    }

    /**
     * @return
     */
    public ArrayList<Offer> getHistory() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public ArrayList<Complaint> getComplaints() {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void Abstract register() {
        // TODO implement here
    }

}