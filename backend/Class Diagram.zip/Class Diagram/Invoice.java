
import java.util.*;

/**
 * 
 */
public class Invoice {

    /**
     * Default constructor
     */
    public Invoice() {
    }

    /**
     * 
     */
    private Offer offer;

    /**
     * 
     */
    private int state;

    /**
     * 
     */
    private DateTime date;

    /**
     * 
     */
    public Double price;

    /**
     * @return
     */
    public bool pay() {
        // TODO implement here
        return null;
    }

}