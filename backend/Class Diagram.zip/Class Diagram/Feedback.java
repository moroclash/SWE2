
import java.util.*;

/**
 * 
 */
public class Feedback {

    /**
     * Default constructor
     */
    public Feedback() {
    }

    /**
     * 
     */
    private String description;

    /**
     * 
     */
    private Offer offer;

    /**
     * 
     */
    private int rateValue;

    /**
     * 
     */
    private DateTime date;


}