
import java.util.*;

/**
 * 
 */
public class ReportFactory {

    /**
     * Default constructor
     */
    public ReportFactory() {
    }

    /**
     * @param Name 
     * @return
     */
    public Report GetReport(String Name) {
        // TODO implement here
        return null;
    }

}